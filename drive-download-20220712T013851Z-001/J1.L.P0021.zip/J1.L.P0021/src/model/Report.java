/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

public class Report {

    String id;
    private String name;
    private int course;
    private int totalCourse;

    /**
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Check id
     *
     * @param id
     * @throws Exception
     */
    public void setId(String id) throws Exception {
        if (!id.isEmpty()) {
            this.id = id;
        } else {
            throw new Exception("ID not empty.");
        }
    }

    /**
     * create a report with parameter
     *
     * @param id
     * @param name
     * @param course
     * @param totalCourse
     */
    public Report(String id, String name, int course, int totalCourse) {
        this.id = id;
        this.name = name;
        this.course = course;
        this.totalCourse = totalCourse;
    }

    /**
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * @return result
     */
    public String getCourseName() {
        String result = null;
        switch (course) {
            case 1:
                result = "Java";
                break;
            case 2:
                result = ".Net";
                break;
            case 3:
                result = "C/C++";
                break;

        }

        return result;
    }

    /**
     * Check name
     *
     * @param name
     */
    public void setName(String name) throws Exception {
        if (!name.isEmpty()) {
            this.name = name;
        } else {
            throw new Exception("Name must not be empty.");
        }
    }

    /**
     * @return course
     */
    public int getCourse() {
        return course;
    }

    /**
     * Check course
     *
     * @param course
     * @throws Exception
     */
    public void setCourse(int course) throws Exception {
        if (course >= 1 && course <= 3) {
            this.course = course;
        } else {
            throw new Exception("Must be in range 1-3");
        }
    }

    /**
     * @return totalCourse
     */
    public int getTotalCourse() {
        return totalCourse;
    }

    /**
     * Check totalCourse
     *
     * @param totalCourse
     */
    public void setTotalCourse(int totalCourse) throws Exception {
        if (totalCourse > 0) {
            this.totalCourse = totalCourse;
        } else {
            throw new Exception("Total courses must be bigger than 0.");
        }
    }

    @Override
    public String toString() {
        return String.format("%-20s | %-10s | %-10s", name, getCourseName(), totalCourse);
    }

}
