/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Ultility {
    //global
    static Scanner scanner = new Scanner(System.in);
     /*
    matches the previous token between one and unlimited times, as many times as possible, giving back as needed (greedy)
    a-z matches a single character in the range between a and z
    A-Z matches a single character in the range between A and Z
    0-9 matches a single character in the range between 0 and 9
     */
    static final String REGEX_STRING = "[a-zA-Z0-9 ]+";
    /*
    0 matches the character 0 literally
    Match a single character present in the list below [0-9]
    {9,10} matches the previous token between 9 and 10 times, as many times as possible, giving back as needed 
    0-9 matches a single character in the range between 0
     */
    static final String REGEX_PHONE = "[0][0-9]{9,10}";
    //Just y-n, Y-N
    static final String REGEX_Y_N = "[yYnN]";
    //Just u-d, U-D
    static final String REGEX_UD = "[uUdD]";
    //Match format dd/MM/yyyy
    static final String DATE_FORMAT = "dd/MM/yyyy";

    /**
     * Return an integer that match format
     * @param message
     * @param error
     * @param min
     * @param max
     * @return 
     */
    public static int getInt(String message, String error, int min, int max) {
        /**
         * matches the previous token between one and unlimited times, as many
         * times as possible, giving back as needed 0-9 matches a single
         * character in the range between 0 and 9
         */
        String REGEX_NUMBER = "[0-9]+";
        //Loop while user input right format
        while (true) {
            System.out.print(message);
            String result = scanner.nextLine();
            //Check if input is empty
            if (result.isEmpty()) {
                System.out.println("Input cannot be empty");
                //neu result khop voi cai regex => cho qua
                //neu khong khop (false )
            }//Check if input not match regex  
            else if (result.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            } else {
                    int number = Integer.parseInt(result);
                    if (number >= min && number <= max) {
                        return number;
                    } else {
                        System.out.println("number must in range from " + min + " to " + max);
                    }

                } 
            }
        }
    

    /**
     * Return a float type
     * @param message
     * @param error
     * @param min
     * @param max
     * @return output
     */
    public static float getFloat(String message, String error, float min, float max) {
        /**
         * matches the previous token between one and unlimited times, as many
         * times as possible, giving back as needed 0-9 matches a single
         * character in the range between 0 and 9
         * . matches .
         */
        String REGEX_NUMBER = "[0-9.]+";
        //Loop while user input right format
        while (true) {
            System.out.print(message);
            String result = scanner.nextLine();
            //Check if input is empty
            if (result.isEmpty()) {
                System.out.println("Input cannot be empty");
            }//Check if input not match regex  
            else if (result.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            } else {
                try {
                    float number = Float.parseFloat(result);
                    if (number > 1 && number < 100) {
                        return number;
                    } else {
                        System.out.println("number must in range from " + min + " to " + max);
                    }
                } catch (NumberFormatException e) {
                    System.out.println(error);
                }
            }
        }
    }

    /**
     * Return a double type
     * @param message
     * @param error
     * @param min
     * @param max
     * @return 
     */
    public static double getDouble(String message, String error, double min, double max) {
        /**
         * matches the previous token between one and unlimited times, as many
         * times as possible, giving back as needed 0-9 matches a single
         * character in the range between 0 and 9
         * . matches .
         */
        String REGEX_NUMBER = "[0-9.]+";
        //Loop while user input right format
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine();
            //Check if input is empty
            if (input.isEmpty()) {
                System.out.println("Input cannot be empty");
            }//Check if input is not match regex 
            else if (input.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            } else {
                try {
                    double output = Double.parseDouble(input);
                        return output;
                } catch (NumberFormatException e) {
                    System.out.println(error);

                }
            }
        }
    }

    /**
     * Return a string type
     * @param message
     * @param error
     * @param regex
     * @return 
     */
    public static String getString(String message, String error, String regex) {
        ///Loop until user input right format
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine();
            //Check if input is empty
            if (input.isEmpty()) {
                System.out.println("Input cannot be empty !!!");
            } else {
                //Check if input is match regex
                if (input.matches(regex)) {
                    return input;
                } else {
                    System.out.println(error);
                }
            }
        }
    }

}
