/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.List;
import model.Task;

/**
 *
 * @author leeph
 */
public class ManageTask {
    List<Task> listTask = new ArrayList<>();
    
    /**
     * Access to list of task
     *
     * @return
     */
    public List<Task> getListTask() {
        return listTask;
    }

    /**
     * Add new task
     *
     * @param task
     */
    public int addTask(String requirementName, int taskType, String date, String assignee, String reviewer, double planFrom, double planTo) {
        //check duplicate
        if (checkDuplicate(requirementName, taskType, date, assignee, reviewer, planFrom, planTo)) {
            return 0;
        }else {
            Task task = new Task(taskType, requirementName, date, assignee, reviewer, planFrom, planTo);
            listTask.add(task);
            return task.getId();
        }
        
    }

    /**
     * Check if multiple tasks is over lap
     *
     * @param planFrom
     * @param planTo
     * @param date
     * @param assignee
     * @return
     */
    private boolean checkDuplicate(String requirementName, int taskType, String date, String assignee, String reviewer, double planFrom, double planTo) {
        for (Task task : listTask) {
            if (task.getDate().equalsIgnoreCase(date)
                    && task.getAssignee().equalsIgnoreCase(assignee)
                    && task.getName().equalsIgnoreCase(requirementName)
                    && task.getReviewer().equalsIgnoreCase(reviewer)
                    && task.getFrom() == (planFrom)
                    && task.getTo() == (planTo)
                    && task.getTypeTask()== (taskType)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Remove task from list
     *
     * @param task
     */
    public void removeTask(Task task) {
        listTask.remove(task);
    }

    /**
     * Check if id input is exist
     *
     * @param id
     * @return
     */
    public Task getTaskByID(int id) {
        for (Task task : listTask) {
            if (task.getId() == id) {
                return task;
            }
        }
        return null;
    }
    
}
