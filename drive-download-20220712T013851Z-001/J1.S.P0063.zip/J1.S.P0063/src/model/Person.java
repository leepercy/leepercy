/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author leeph
 */
public class Person {

    private String name;
    private String address;
    private double salary;

    public Person() {
    }

    /**
     * Create person's information object
     */
    public Person(String name, String address, double salary) {
        this.name = name;
        this.address = address;
        this.salary = salary;
    }


    /*
    Return name value
     */
    public String getName() {
        return name;
    }

    /*
    Sets name not empty
     */
    public void setName(String name) throws Exception{
        //if name is not empty
        if (!name.isEmpty()) {
            this.name = name;
        }else{
            throw new Exception("Name can not be empty");
        }
    }

    /*
    Return address value
     */
    public String getAddress() {
        return address;
    }

    /*
    Sets address not empty
     */
    public void setAddress(String address) throws Exception{
        //if address is not empty
        if (!address.isEmpty()) {
            this.address = address;
        }else{
            throw new Exception("Address can not be empty.");
        }
    }

    /*
    Return salary value
     */
    public double getSalary() {
        return salary;
    }

    /*
    Sets salary bigger than 0
     */
    public void setSalary(double salary) throws Exception {
        //if salary is bigger than 0
        if (salary > 0) {
            this.salary = salary;
        }else{
            throw new Exception("Salary can not be less than 0.");
        }
    }

    /*
    Display output
    */
    public String toString() {
        return "Name:" + name + "\nAddress:" + address + "\nSalary:" + salary;
    }

}
