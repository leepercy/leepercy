/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.util.Scanner;

/**
 *
 * @author leeph
 */
public class Utility {

    static Scanner scanner = new Scanner(System.in);

    /**
     * Return a string type
     *
     * @param message
     * @param error
     * @param REGEX
     * @return input
     */
    public static String getString(String message, String error, String REGEX) {
        //Loop if user input wrong
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine();
            //check if input is empty
            if (input.isEmpty()) {
                System.out.println("Input can not be empty.");
                //check if input not match regex    
            } else if (!input.matches(REGEX)) {
                System.out.println(error);
            } else {
                return input;
            }
        }
    }

    /**
     * Return a double type
     *
     * @param message
     * @param error
     * @return salary
     */
    public static double getDouble(String message, String error) {
        //Loop until user input right format
        while (true) {
            /**
             * matches the previous token between one and unlimited times, as
             * many times as possible, giving back as needed 0-9 matches a
             * single character in the range between 0 and 9 matches the
             * character .
             */
            System.out.print(message);
            String input = scanner.nextLine();
            //check if input is empty
            if (input.isEmpty()) {
                System.out.println("Input can not be empty.");
            } else {
                try {
                    double number = Double.parseDouble(input);
                    //Check if input is less than 0
                    if (number <= 0) {
                        System.out.println("Salary is greater than zero");
                    } else {
                        return number;
                    }
                } catch (Exception e) {
                    System.out.println("Wrong format.");
                }
            }
        }

    }

}
