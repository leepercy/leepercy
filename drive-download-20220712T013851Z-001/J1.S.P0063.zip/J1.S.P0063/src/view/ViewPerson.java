/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.ManagePerson;
import model.Person;

/**
 *
 * @author leeph
 */
public class ViewPerson {

    ManagePerson manage = new ManagePerson();

    /**
     * This function add persons
     */
    void inputPersonInfo() {
        System.out.println("=====Management Person programer=====");
        //Loop until have enough 3 person
        while (manage.getListPerson().size() < 3) {
            System.out.println("Input Information of Person");
            String name = getName();
            String address = getAddress();
            double salary = getSalary();

            Person person = new Person(name, address, salary);
            manage.addPerson(person);
        }
    }

    /**
     * This function check if user don't input anything and when enough 3
     * persons , it will sort person by salary
     */
    void sortBySalary() {
        
        manage.sortBySalary();
    }

    /**
     * This function display the information when it has enough persons
     */
    void displayPersonInfo() {
       
        //Loop from first to last person and display
        for (Person person : manage.getListPerson()) {
            System.out.println("\nInformation of Person you have entered:");
            System.out.println(person);
        }
    }

    /**
     * Check name if empty, match REGEX or not
     * @return name
     */
    private String getName() {
        /**
         *  matches the previous token between one and unlimited times, as many times as possible, giving back as needed 
         *  a-z matches a single character in the range between a and z
         *  A-Z matches a single character in the range between A and Z
         */
        String name = Utility.getString("Please input name:", "You must input alphabet type.", "[a-zA-Z ]+");
        return name;
    }

    /**
     * Check address if empty, match REGEX or not
     * @return address
     */
    private String getAddress() {
        /**
         * matches the previous token between one and unlimited times, as many times as possible, giving back as needed 
         * a-z matches a single character in the range between a and z
         * A-Z matches a single character in the range between A (index 65) and Z
         * 0-9 matches a single character in the range between 0 and 9
         */
        String address = Utility.getString("Please input address:", "You must input character.", "[a-zA-Z0-9 ]+");
        return address;
    }

    /**
     * Check salary if empty, match REGEX_STRING or not
     * @return salary
     */
    private double getSalary() {
        double salary = Utility.getDouble("Please input salary:", "You must input digit.");
        return salary;
    }

}
