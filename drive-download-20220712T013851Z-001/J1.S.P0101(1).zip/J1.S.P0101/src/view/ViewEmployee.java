/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.ManageEmployee;
import java.util.List;
import model.Employee;

/**
 *
 * @author leeph
 */
public class ViewEmployee {

    ManageEmployee manage = new ManageEmployee();

    /**
     * Show the menu to screen
     */
    void displayMenu() {
        System.out.println("                              MENU\n"
                + "==========================================================================\n"
                + "1. Add employees\n"
                + "2. Update employees\n"
                + "3. Remove employees\n"
                + "4. Search employees  \n"
                + "5. Sort employees by salary \n"
                + "6. Exit \n"
                + "==========================================================================");
    }

    /**
     * Add new employee's information to listEmployees
     */
    void addEmployees() {
        String id = getID();
        String firstName = getFirstName();
        String lastName = getLastName();
        String phone = getPhone();
        String email = getEmail();
        String address = getAddress();
        String DOB = getDOB();
        int sex = getSex();
        double salary = getSalary();
        String agency = getAgency();
        System.out.format("%-5s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
        Employee employee = new Employee(id ,firstName, lastName, phone, email, address, DOB, agency, salary, sex);
        manage.addEmployee(employee);
        System.out.println(employee);
    }

    /**
     * Update employee's information and asking them update or not
     */
    void updateEmployees() throws Exception {
        String id = getID();

        /**
         * Searching employee's id in listEmployee
         */
        Employee employee = manage.getEmployeeByID(id);
        //Check if no employee in listEmployee
        if (employee == null) {
            System.out.println("NOT FOUND EMPLOYEE");
            return;
        }

        while (true) {
            System.out.println("                         Update information\n"
                    + "==========================================================================\n"
                    + "1. Update first name\n"
                    + "2. Update last name\n"
                    + "3. Update phone number\n"
                    + "4. Update email\n"
                    + "5. Update address\n"
                    + "6. Update date of birth\n"
                    + "7. Update sex\n"
                    + "8. Update salary\n"
                    + "9. Update agency\n"
                    + "10.Exit\n"
                    + "==========================================================================");
            int choice = Utility.getInt("Your choice: ",
                    "Please input a digt number.", 1, 10);
            switch (choice) {
                case 1:
                    //Check if user want to update id that existed before
                    if (checkWantToUpdate("id")) {
                        while (true) {
                            String IDUpdate = getID();
                            //If id is duplicate
                            if (manage.checkDuplicate(IDUpdate)) {
                                System.out.println("ID was existed !!");
                            } else {
                                employee.setId(IDUpdate);
                                System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                                System.out.println(employee);
                                break;
                            }
                        }
                    }
                    break;
                case 2:
                    //Check if user watnt to update first name
                    if (checkWantToUpdate("first name")) {
                        String firstName = getFirstName();
                        employee.setFirstName(firstName);
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 3:
                    //Check if user watnt to update last name
                    if (checkWantToUpdate("last name")) {
                        String lastName = getLastName();
                        employee.setLastName(lastName);
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 4:
                    //Check if user watnt to update phone number
                    if (checkWantToUpdate("phone")) {
                        String phone = getPhone();
                        try {
                            employee.setPhone(phone);
                        } catch (Exception ex) {
                            System.out.println("Parse error.");
                        }
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 5:
                    //Check if user watnt to update email
                    if (checkWantToUpdate("email")) {
                        String email = getEmail();
                        try {
                            employee.setEmail(email);
                        } catch (Exception ex) {
                            System.out.println("Parse error.");
                        }
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 6:
                    //Check if user watnt to update address
                    if (checkWantToUpdate("address")) {
                        String address = getAddress();
                        employee.setAddress(address);
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 7:
                    //Check if user watnt to update date of birth
                    if (checkWantToUpdate("DOB")) {
                        String DOB = getDOB();
                        employee.setDOB(DOB);
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 8:
                    //Check if user watnt to update sex
                    if (checkWantToUpdate("sex")) {
                        int sex = getSex();
                        employee.setSex(sex);
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 9:
                    //Check if user watnt to update salary
                    if (checkWantToUpdate("salary")) {
                        double salary = getSalary();
                        employee.setSalary(salary);
                        System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
                        System.out.println(employee);
                    }
                    break;
                case 10:
                    System.exit(0);
                    break;
                    
            }

        }

    }

    /**
     * Remove an employee's information by id
     */
    void removeEmployees() {
        String id = getID();
        Employee employee = manage.getEmployeeByID(id);

        //If id not exist
        if (employee == null) {
            System.out.println("NOT FOUND EMPLOYEE");
        } else {
            manage.removeEmployee(employee);
        }
    }

    /**
     * Searching employee's information by name or part of name
     */
    void searchEmployees() {
        String name = getName();
        List<Employee> listSearch = manage.getEmployeeByName(name);

        //if no employee in listEmployee
        if (listSearch.size() == 0) {
            System.out.println("NOT FOUND");
        } else {
            System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
            displayListEmployee(listSearch);
        }
    }

    /**
     * Sort employee's information by salary
     */
    void sortEmployeesBySalary() {
        List<Employee> listSort = manage.sortEmployee();
        //if no employee in list
        if (listSort.size() == 0) {
            System.out.println("LIST IS EMPTY");
        } else {
            System.out.format("%-10s|%-20s|%-20s|%-20s|%-20s|%-20s|%-10s|%-10s|"
                + "%-10s|%-10s\n", "id", "First name", "Last name", "Phone", "Email", "Address", "Date of birth", "Sex", "Salary", "Agency");
            //display all employee's iformation in listEmployee
            displayListEmployee(listSort);
        }
    }

    /**
     * Check first name is not empty, match REGEX_NAME or not
     *
     * @return firstName
     */
    private String getFirstName() {
        String firstName = Utility.getString("Enter first name: ", "Please input character.", Utility.REGEX_NAME);
        return firstName;
    }

    /**
     * Check last name is not empty, match REGEX_NAME or not
     *
     * @return lastName
     */
    private String getLastName() {
        String lastName = Utility.getString("Enter last name: ", "Please input character.", Utility.REGEX_NAME);
        return lastName;
    }

    /**
     * Check phone number is not empty, match REGEX_PHONE or not
     *
     * @return phone
     */
    private String getPhone() {
        String phone = Utility.getString("Enter phone number: ", "Must be 10 or 11 digits and start with 0.", Utility.REGEX_PHONE);
        return phone;
    }

    /**
     * Check email is not empty, match REGEX_EMAIL or not
     *
     * @return email
     */
    private String getEmail() {
        String email = Utility.getString("Enter email: ", "Error.", Utility.REGEX_EMAIL);
        return email;
    }

    /**
     * Check address is not empty, match REGEX_STRING or not
     *
     * @return address
     */
    private String getAddress() {
        String address = Utility.getString("Enter address: ", "Please input a character.", Utility.REGEX_STRING);
        return address;
    }

    /**
     * Check date of birth is not empty, match REGEX_DATE or not
     *
     * @return DOB
     */
    private String getDOB() {
        String DOB = Utility.getDate("Enter date of birth: ", "Please input in format dd/mm/yyyy.", Utility.REGEX_DATE);
        return DOB;
    }

    /**
     * Check agency is not empty, match REGEX_STRING or not
     *
     * @return agency
     */
    private String getAgency() {
        String agency = Utility.getString("Enter agency: ", "Please input a character.", Utility.REGEX_STRING);
        return agency;
    }

    /**
     * Check sex is not empty, match REGEX_NUMBER or not
     *
     * @return sex
     */
    private int getSex() {
        int sex = Utility.getInt("Enter sex (1: male, 0: female)", "Please input a digit.", 0, 1);
        return sex;
    }

    /**
     * Check salary is not empty, match REGEX_NUMBER or not
     *
     * @return salary
     */
    private double getSalary() {
        double salary = Utility.getDouble("Enter salary: ", "Please input a digit.");
        return salary;
    }

    /**
     * Check id is not empty, match REGEX_NUMBER or not
     *
     * @return lastName
     */
    private String getID() {
        String id = Utility.getString("Enter id: ", "Wrong format.", Utility.REGEX_STRING);
        return id;
    }

    /**
     * Check choice from user is not empty, match REGEX_Y_N or not
     *
     * @return lastName
     */
    private boolean checkWantToUpdate(String string) {
        String answer = Utility.getString("Do you want to update " + string + " ? (y/n)", "It must be y or n ", Utility.REGEX_Y_N);
        //if user want to update
        if (answer.equalsIgnoreCase("y")) {
            return true;
        }//if user don't want to update
        else {
            return false;
        }
    }

    /**
     * Check last name is not empty, match REGEX_NAME or not
     *
     * @return lastName
     */
    private String getName() {
        String name = Utility.getString("Enter name: ", "Please input name.", Utility.REGEX_STRING);
        return name;
    }

    /**
     * Display employee's information
     *
     * @param listSearch
     */
    private void displayListEmployee(List<Employee> listSearch) {
        for (Employee employee : listSearch) {
            System.out.println(employee);
        }
    }

}
