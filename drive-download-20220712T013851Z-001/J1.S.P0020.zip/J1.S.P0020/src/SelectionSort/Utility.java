/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SelectionSort;

import java.util.Scanner;

/**
 *
 * @author leeph
 */
public class Utility {

    //Cho phép chúng ta đọc các đầu vào thuộc các kiểu khác nhau
    static Scanner scanner = new Scanner(System.in);

    /**
     * Get an integer number from input
     *
     * @param message
     * @param error
     * @param min
     * @param max
     * @return an integer number
     */
    public static int getInt(String message, String error, int min, int max) {
        //loop until true
        while (true) {
            //0-9 matches a single character in the range between 0 and 9
            //matches the previous token between one and unlimited times, as many times as possible, giving back as needed
            String REGEX_NUMBER = "[0-9]+";
            System.out.print(message);
            String input = scanner.nextLine();
            //Check input is empty or not
            if (input.isEmpty()) {
                System.out.println("Empty.");
                //Kiểm tra nếu người dùng nhập sai giá trị hợp lệ sẽ báo lỗi    
            }//Check input matches REGEX_NUMBER or not 
            else if (input.matches(REGEX_NUMBER) == false) {
                System.out.println("Please input an integer number.");
            }//Check if number is in range or not 
            else {
                try {
                    int number = Integer.parseInt(input);
                    //if number is in range
                    if (number >= min && number <= max) {
                        return number;
                    }//if number not in range 
                    else {
                        System.out.println("Please input a number bigger than 0.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println(error);
                }

            }
        }

    }

    /**
     * Check a double type is valid or not
     * @return double number
     */
    public static double getDouble() {
        //Loop until user enter right format
        while (true) {
            System.out.print("Input number: ");
            String input = scanner.nextLine();
            //Check input is empty 
            if (input.isEmpty()) {
                System.out.println("Empty.");
            }//Check if input not match REGEX_NUMBER 
            else {
                try {
                    double number = Double.parseDouble(input);
                    return number;
                    }
                 catch (NumberFormatException e) {
                    System.out.println("Wrong format number !");
                }

            }
        }

    }

}
