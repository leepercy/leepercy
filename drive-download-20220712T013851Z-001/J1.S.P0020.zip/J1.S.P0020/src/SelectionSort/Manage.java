/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SelectionSort;

public class Manage {

    /**
     * Sort an array by ascending number into selection sort
     *
     * @param array
     */
    public static void selectionSort(double [] array) {
        int size = array.length;
        //Loop from first to last element and one is sorted.
        for (int i = 0; i < size - 1; i++) {
            //Finding smallest index in array
            int min = i;
            //Loop through unsored element. 
            for (int j = i + 1; j < size; j++) {
                /*
                Check from left to right and if number in left is bigger than right
                then swap it.
                 */
                if (array[j]< array [i]) {
                    min = j;
                }
                //Swap index smallest and index biggest
                double temp = array[min];
                array[min] = array[i];
                array[i] = temp;
            }
        }
    }
}
