
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SelectionSort;

import java.util.Arrays;
import java.util.Scanner;

public class ViewArray {

    public static Scanner SCANNER = new Scanner(System.in);

    /**
     * Create an array and user enter number of size and digit into it
     *
     * @param number
     * @return array
     */
    public static double[] getArray(int number) {
        double [] array = new double [number];
        //Loop from first to last element
        for (int i = 0; i < array.length; i++) {
            //Loop until user input right condition 
            while (true) {
                try {
                    double ranNum = Utility.getDouble();
                    array[i] = ranNum;
                    break;
                } catch (Exception e) {
                    System.err.println("Invalid input, please enter number !");
                }
            }
        }
        return array;
    }

    /**
     * Display a message
     *
     * @param message
     * @param array
     */
    public static void displayArray(String message, double [] array) {
        System.out.print(message + Arrays.toString(array));
    }

}
