/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SelectionSort;

public class Main {

  
    
    public static void main(String[] args) {
        ViewArray view = new ViewArray();
        /*
        *Users run the program, display a screen to 
        *ask users to enter a positive decimal number.
        */
        int number = Utility.getInt("Please enter a positive decimal number: ", "Out of memory.", 1, 100);
        //Users input elements of array
        double [] array = view.getArray(number);
        //Display array before sorting
        view.displayArray("Unsorted array: ", array);
        System.out.println("\n");
        //Display array after sorting
        Manage.selectionSort(array);
        view.displayArray("Sorted array: ", array);
        System.out.println("\n");
    }
    
}
