package view;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import controller.ManageEastAsiaCountries;
import java.util.ArrayList;
import java.util.List;
import model.EastAsiaCountries;

/**
 *
 * @author leeph
 */
public class ViewCountry {

    ManageEastAsiaCountries manage = new ManageEastAsiaCountries();

    /**
     * This method display a menu and ask users to select an option.
     */
    public void displayMenu() {
        System.out.println("                              MENU\n"
                + "==========================================================================\n"
                + "1. Input the information of 11 countries in East Asia\n"
                + "2. Display the information of country you've just input\n"
                + "3. Search the information of country by user-entered name\n"
                + "4. Display the information of countries sorted name in ascending order  \n"
                + "5. Exit \n"
                + "==========================================================================");
    }

    /**
     * This method allow user input country's information
     *
     */
    public void addCountryInformation() {
        String code = getCode();

        /*
        Check duplicate code
        If has a country's code in list => print error
         */
        if (manage.getCountryByCode(code) != null) {
            System.out.println("Duplicate code.");
        } else {
            String name = getName();
            if (manage.getCountryByName(name) != null) {
                System.out.println("Duplicate name");
            } else {
                float area = getArea();
                String terrarin = getTerrain();
                EastAsiaCountries country = new EastAsiaCountries(terrarin, code, name, area);
                manage.addCountry(country);
                System.out.format("%-15s %-15s %-15s %-15s\n", "ID", "Name", "Total area", "Terrain");
                country.display();
                System.out.println("");
            }
        }
    }

    /**
     * This method display country's information
     *
     */
    public void getRecentlyEnteredInformation() {
        /*
        Check if size of country's list = 0
         */
        if (manage.getListCountry().size() == 0) {
            System.out.println("No country in list");
        } else {
            System.out.format("%-15s %-15s %-15s %-15s\n", "ID", "Name", "Total area", "Terrain");
            manage.getListCountry().get(manage.getListCountry().size() - 1).display();
            System.out.println("");

        }
    }
//

    /**
     * This method find country's information by user-entered name
     *
     * @param manage.getListCountry()
     */
    public void searchInformationByName() {
        List<EastAsiaCountries> listCountry = new ArrayList<>();
        String nameCountry = getName();
        //Searching coutry that user input name
        listCountry = manage.searchCounry(nameCountry);
        //Check if list of country is empty
        if (listCountry.isEmpty()) {
            System.out.println("No country to find.");
        } else {
            System.out.format("%-15s %-15s %-15s %-15s\n", "ID", "Name", "Total area", "Terrain");
            for (EastAsiaCountries eastAsiaCountry : listCountry) {
                eastAsiaCountry.display();
            }
        }
    }

    /**
     * This method display the information of countries sorted name in ascending
     * order
     *
     * @param manage.getListCountry()
     */
    public void sortInformationByAscendingOrder() {
        /*
        Check if country's list is empty
         */
        List<EastAsiaCountries> listSort = manage.sortByName();
        if (listSort.isEmpty()) {
            System.out.println("No country in list.");
        } else {
            for (EastAsiaCountries eastAsiaCountry : listSort) {
                eastAsiaCountry.display();
            }
        }

    }

    /**
     * Check code if empty, match REGEX_STRING
     *
     * @return code
     */
    private String getCode() {
        String code = Utility.getString("Enter code of country: ", "Must be 2 or 3 alphabet.", "[A-Za-z]{2,3}+").toUpperCase();
        return code;
    }

    /**
     * Check name if empty, match REGEX_STRING
     *
     * @return
     */
    private static String getName() {
        String name = Utility.getString("Enter name of country: ", "You must type alphabet.", Utility.REGEX_STRING);
        return name;
    }

    /**
     * Check area if empty, match REGEX_NUMBER
     *
     * @return
     */
    private float getArea() {
        float area = Utility.getFloat("Enter total Area: ", "You must enter float type.", 0, Float.MAX_VALUE);
        return area;
    }

    /**
     * Check terrain if empty, match REGEX_STRING
     *
     * @return
     */
    private String getTerrain() {
        String terrain = Utility.getString("Enter terrain of country: ", "You must type alphabet.", Utility.REGEX_STRING);
        return terrain;
    }

}
