/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.util.Scanner;

/**
 *
 * @author leeph
 */
public class Utility {

    static Scanner scanner = new Scanner(System.in);
    /**
     * matches the previous token between one and unlimited times, as many times as possible, giving back as needed 
     * a-x matches a single character in the range between a and x 
     * A-Z matches a single character in the range between A and Z 
     */
    static final String REGEX_STRING = "[a-xA-Z ]+";
    
    /**
     * matches the previous token between one and unlimited times, as many times as possible, giving back as needed
     * 0-9 matches a single character in the range between 0 and 9
     */
    static final String REGEX_NUMBER = "[0-9]+";
    
    /**
     * matches the previous token between one and unlimited times, as many times as possible, giving back as needed
     * 0-9 matches a single character in the range between 0 and 9
     * . matches the character . 
     */
    static final String REGEX_FLOAT = "[0-9.]+";

    /**
     * Get an integer number from input
     *
     * @param message
     * @param error
     * @param min
     * @param max
     * @return an integer number
     */
    public static int getInt(String message, String error, int min, int max) {
        //Loop until user enter right format
        while (true) {
            System.out.print(message);
            String input = scanner.nextLine();
            //Check input is empty or not
            if (input.isEmpty()) {
                System.out.println("Empty.");
            }//Check input matches REGEX_NUMBER or not 
            else if (input.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            }//Check if number is in range or not 
            else {
                    int number = Integer.parseInt(input);
                    //if number is in range
                    if (number >= min && number <= max) {
                        return number;
                    }//if number not in range 
                    else {
                        System.out.println("Not in range number request " + min + " - " + max );
                    }
                } 
            }
        }

    /**
     * Get a float number from input
     *
     * @param message
     * @param error
     * @param min
     * @param max
     * @return a float number
     */
    public static float getFloat(String message, String error, float min, float max) {
        while (true) {
            System.out.println(message);
            String input = scanner.nextLine();
            //Check if input is empty   
            if (input.isEmpty()) {
                System.out.println("Please input a number !");
            }//Check if input not matches REGEX_NUMBER
            else if (input.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            }//Check if number not in range 
            else {
                    float number = Float.parseFloat(input);
                    //Check if number is in range
                    if (number > min && number <= max) {
                        return number;
                    }//Check if number not in range 
                    else {
                        System.out.println("The number must be bigger than 0.");
                    }
                }

            }
        }

    /**
     * Return a string from user input
     *
     * @param message
     * @param error
     * @param REGEX
     * @return a string
     */
    public static String getString(String message, String error, String REGEX) {
        //Loop if user input wrong
        while (true) {
            System.out.println(message);
            String input = scanner.nextLine();
            //check if input is empty
            if (input.isEmpty()) {
                System.out.println("Empty !");
                //check if input not match regex    
            } else if (!input.matches(REGEX)) {
                System.out.println(error);
            } else {
                return input;
            }
        }
    }
}
