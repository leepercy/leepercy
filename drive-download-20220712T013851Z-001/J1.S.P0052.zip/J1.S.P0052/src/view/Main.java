/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.ManageEastAsiaCountries;

/**
 *
 * @author leeph
 */
public class Main {

    public static void main(String[] args) throws Exception {
        ManageEastAsiaCountries manage = new ManageEastAsiaCountries();
        ViewCountry view = new ViewCountry();
        /**
         * Loop until user press 5 to exit
         */
        while (true) {
            view.displayMenu();
            int option = Utility.getInt("Please select option: ", "It must be an integer number.", 1, 5);
            switch (option) {
                case 1:
                    //1. Enter the information for 11 countries in Southeast Asia.
                    view.addCountryInformation();
                    break;
                case 2:    
                    //2. Display already information.
                    view.getRecentlyEnteredInformation();
                    break;
                case 3:    
                    //3. Search the country according to the entered country's name.
                    view.searchInformationByName();
                    break;
                case 4:    
                    //4. Display the information increasing with the country name.
                    view.sortInformationByAscendingOrder();
                    break;
                case 5:    
                    //5. Exit.
                    System.exit(0);
                default:
                    System.out.println("Must be in range 1-5.");
            }

        }

    }

}
