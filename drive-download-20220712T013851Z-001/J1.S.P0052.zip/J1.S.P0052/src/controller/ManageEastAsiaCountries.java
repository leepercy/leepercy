/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import model.EastAsiaCountries;

/**
 *
 * @author leeph
 */
public class ManageEastAsiaCountries {

    List<EastAsiaCountries> listCountry = new ArrayList<>();

    /**
     * This method allow to access list of EastAsiaCountry
     *
     * @return listCountry
     */
    public List<EastAsiaCountries> getListCountry() {
        return listCountry;
    }

    /**
     * This method add new country's information to listCountry
     *
     * @param country
     */
    public void addCountry(EastAsiaCountries country) {
        listCountry.add(country);
    }

    /**
     * This method check if country's code is match with code parameter that was
     * typed before.
     *
     * @param code
     * @return
     */
    public EastAsiaCountries getCountryByCode(String code) {
        /*
        Use loop to find that country's code is match with code parameter => 
        return that country
        If the loop is done and no return back, it will return null
         */
        for (EastAsiaCountries eastAsiaCountry : listCountry) {
            if (eastAsiaCountry.getCountryCode().equals(code)) {
                return eastAsiaCountry;
            }
        }

        return null;
    }
    
    /**
     * This method check if country's name is match with name parameter that was
     * typed before.
     *
     * @param name
     * @return
     */
    public EastAsiaCountries getCountryByName(String name) {
        /*
        Use loop to find that country's code is match with code parameter => 
        return that country
        If the loop is done and no return back, it will return null
         */
        for (EastAsiaCountries eastAsiaCountry : listCountry) {
            if (eastAsiaCountry.getCountryName().equals(name)) {
                return eastAsiaCountry;
            }
        }

        return null;
    }

    /**
     * This method sorting country's information by ascending name
     *
     * @return listSort
     */
    public List<EastAsiaCountries> sortByName() {
        List<EastAsiaCountries> listSort = new ArrayList<>();
        listSort.addAll(listCountry);
        /**
         * Loop from the first to last elements, it will take the first letter
         * of name1 to compare with name2 in alphabetical order
         */
        for (int i = 0; i < listSort.size() - 1; i++) {
            for (int j = 0; j < listSort.size() - i - 1; j++) {
                if (listSort.get(j).getCountryName().equals(listSort.get(j + 1).getCountryName()) == false) {
                    Collections.swap(listSort, j, j + 1);
                }
            }
        }

        return listSort;
    }

    /**
     * This method search country's information by name
     *
     * @param countryName
     * @return listFound
     */
    public List<EastAsiaCountries> searchCounry(String countryName) {
        List<EastAsiaCountries> listFound = new ArrayList<>();
        /**
         * Loop from first to last elements. If country has same contain name
         * parameters => add into listFound
         */
        for (EastAsiaCountries eastAsiaCountry : listCountry) {
            if (eastAsiaCountry.getCountryName().toLowerCase().contains(countryName.toLowerCase())) {
                listFound.add(eastAsiaCountry);
            }
        }
        return listFound;
    }

}
