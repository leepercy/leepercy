/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author leeph
 */
public class EastAsiaCountries extends Country {

    protected String terrain;

    public EastAsiaCountries() {
    }

    /**
     * Creates a eastAsiaCountries's information that extends properties from
     * country
     */

    public EastAsiaCountries(String terrain, String countryCode, String countryName, float totalArea) {
        super(countryCode, countryName, totalArea);
        this.terrain = terrain;
    }

    /**
     * Return terrain in the eastAsiaCountries
     *
     * @return terrain
     */
    public String getTerrain() {
        return terrain;
    }

    /**
     * Sets terrain not empty
     *
     * @param terrain
     * @throws java.lang.Exception
     */
    public void setTerrain(String terrain) throws Exception {
        //if terrain is not empty
        if (!terrain.isEmpty()) {
            this.terrain = terrain;
        }else{
            throw new Exception("Terrain can not be empty.");
        }
    }

    /**
     * Display in format
     */
    public void display() {
        System.out.format("%-15s %-15s %-15s %-15s\n", countryCode, countryName, totalArea, terrain);
    }
}
