/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.swing.text.html.HTML;
import view.Utility;

/**
 *
 * @author leeph
 */
public class Country {

    protected String countryCode;
    protected String countryName;
    protected float totalArea;

    public Country() {
    }

    /**
     * Creates a country's information object
     */
    public Country(String countryCode, String countryName, float totalArea) {
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.totalArea = totalArea;
    }

    /*
    Return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Check countryCode is in format or not
     *
     * @param countryCode
     * @throws java.lang.Exception
     */
    public void setCountryCode(String countryCode) throws Exception{
        //if country's code is not empty
        if (!countryCode.isEmpty()) {
            this.countryCode = countryCode;
        }else{
            throw new Exception("Country code can not be empty.");
        }
}

    /*
    Return countryName
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Check countryName is in format or not
     *
     * @param countryName
     * @throws java.lang.Exception
     */
    public void setCountryName(String countryName) throws Exception{
        //if country's name is not empty
        if (!countryName.isEmpty()) {
            this.countryName = countryName;
        }else{
            throw new Exception("Country name can not be empty.");
        }
    }

    /*
    Return totalArea
     */
    public float getTotalArea() {
        return totalArea;
    }

    /**
     * Check totalArea is in format or not
     *
     * @param totalArea
     * @throws java.lang.Exception
     */
    public void setTotalArea(float totalArea) throws Exception {
        //if total is bigger than 0
        if(totalArea > 0){
            this.totalArea = totalArea;
        }else{
            throw new Exception("Area must bigger than 0.");
        }
    }

}
