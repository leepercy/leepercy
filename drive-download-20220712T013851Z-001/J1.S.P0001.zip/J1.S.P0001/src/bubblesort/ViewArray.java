/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bubblesort;

import java.util.Arrays;
import java.util.Scanner;

public class ViewArray {

    /**
     * This function used to check the validation input
     */
    public static Scanner SCANNER = new Scanner(System.in);

    /**
     * Check condition input from use
     *
     * @return number
     */
    public static int getInt(String message, String error, int min, int max) {
        //loop until true
        while (true) {
            //0-9 matches a single character in the range between 0 and 9
            //matches the previous token between one and unlimited times, as many times as possible, giving back as needed
            String REGEX_NUMBER = "[0-9]+";
            System.out.print(message);
            String input = SCANNER.nextLine();
            //Check input is empty or not
            if (input.isEmpty()) {
                System.out.println("Empty.");
                //Kiểm tra nếu người dùng nhập sai giá trị hợp lệ sẽ báo lỗi    
            }//Check input matches REGEX_NUMBER or not 
            else if (input.matches(REGEX_NUMBER) == false) {
                System.out.println("Please enter an integer number.");
            }//Check if number is in range or not 
            else {
                try {
                    int number = Integer.parseInt(input);
                    //if number is in range
                    if (number >= min && number <= max) {
                        return number;
                    }//if number not in range 
                    else {
                        System.out.println("Please input a number in range " + min + " to " + max);
                    }
                } catch (NumberFormatException e) {
                    System.out.println(error);
                }

            }
        }

    }

    /**
     * Display a message
     *
     * @param message
     * @param array
     */
    public static void displayArray(String message, int[] array) {
        System.out.print(message + Arrays.toString(array));
    }

}
