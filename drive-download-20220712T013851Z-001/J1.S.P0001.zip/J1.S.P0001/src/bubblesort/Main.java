/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bubblesort;


 
public class Main {

    
    public static void main(String[] args) {
        //Allow user input an array
        int number = ViewArray.getInt("Enter number of array:", "Out of mermory.", 1, 1000);
        //An array is randomly created in integer number
        int[] array = Manage.getArray(number);
        //Display unsorted number
        ViewArray.displayArray("Unsorted array: ", array);
        System.out.println("\n");
        //Sorting ascending
        Manage.bubbleSort(array);
        //Display sorted array
        ViewArray.displayArray("Sorted array: ", array);
        System.out.println("\n");
    }
    
}
