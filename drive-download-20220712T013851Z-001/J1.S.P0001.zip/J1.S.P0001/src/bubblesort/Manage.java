/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bubblesort;

import java.util.Arrays;
import java.util.Random;

    /*
     * @purpose: Hàm này sẽ thực thi nhiệm vụ
     * khi người dùng sử dụng chương trình
     */
public class Manage {
    
    
    /**
     * Create an array with randomly number
     * @param number
     * @return array
     */
    public static int[] getArray(int number){
        int[] array = new int[number];
        //Loop from first to last element in array
        for(int i = 0; i < array.length; i++){
            array[i] = new Random().nextInt(number);
        }
        return array;
    }
    
    
    
    /**
     * Sorting an array by ascending in bubble sort
     * @param array 
     */
    public static void bubbleSort(int[] array) {
        int size = array.length;
        /*
        Loop from first to last element and will return one sorted in array.
        */
        for (int i = 0; i < size - 1; i++) {
            //Loop through unsorted element.
            for (int j = 0; j < size - i - 1; j++) {
                //Check left to right, if one in left is bigger than one in right
                //then swap them.
                if (array[j] > array[j + 1]) {                  
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
            
        }      
    }
}
