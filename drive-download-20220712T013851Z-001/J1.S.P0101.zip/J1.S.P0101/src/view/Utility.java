/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author leeph
 */
public class Utility {

    static Scanner scanner = new Scanner(System.in);
    /**
     * matches the previous token between one and unlimited times, as many times
     * as possible, giving back as needed a-z matches a single character in the
     * range between a and z A-Z matches a single character in the range between
     * A
     */
    static final String REGEX_NAME = "[a-zA-Z ]+";
    /*
    matches the previous token between one and unlimited times, as many times as possible, giving back as needed (greedy)
    a-z matches a single character in the range between a and z
    A-Z matches a single character in the range between A and Z
    0-9 matches a single character in the range between 0 and 9
     */
    static final String REGEX_STRING = "[a-zA-Z0-9 ]+";
    //yYnN matches a single character in the list yYnN 
    static final String REGEX_Y_N = "[yYnN]";
    /*
    0 matches the character 0 literally
    Match a single character present in the list below [0-9]
    {9,10} matches the previous token between 9 and 10 times, as many times as possible, giving back as needed 
    0-9 matches a single character in the range between 0
     */
    static final String REGEX_PHONE = "[0][0-9]{9,10}";
    /*
    \w matches any word character (equivalent to [a-zA-Z0-9_])
    @ matches the character @
    {1,2} matches the previous token between 1 and 2 times, as many times as possible, 
    [\w] matches the previous token between one and unlimited times, as many times as possible, giving back as needed (greedy)
    \w matches any word character (equivalent to [a-zA-Z0-9_])
    . matches the character .
    Match a single character present in the list below [\\w-]
    {2,4} matches the previous token between 2 and 4 times, as many times as possible, giving back as needed (greedy)
    */
    static final String REGEX_EMAIL = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
    //Format date in dd/MM/yyyy
    static final String REGEX_DATE = "\\d{1,2}[/]\\d{1,2}[/]\\d{4}";
    //Format date in dd/MM/yyyy
    static final String DATE_FORMAT = "dd/MM/yyyy";

    /**
     * Get an integer number from input
     *
     * @param message
     * @param error
     * @param min
     * @param max
     * @return an integer number
     */
    public static int getInt(String message, String error, int min, int max) {
        String REGEX_NUMBER = "[0-9]+";
        //loop until true
        while (true) {
            //0-9 matches a single character in the range between 0 and 9
            //matches the previous token between one and unlimited times, as many times as possible, giving back as needed
            System.out.println(message);
            String input = scanner.nextLine();
            //Check input is empty or not
            if (input.isEmpty()) {
                System.out.println("Empty.");
                //Kiểm tra nếu người dùng nhập sai giá trị hợp lệ sẽ báo lỗi    
            }//Check input matches REGEX_NUMBER or not 
            else if (input.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            }//Check if number is in range or not 
            else {
                    int number = Integer.parseInt(input);
                    //if number is in range
                    if (number >= min && number <= max) {
                        return number;
                    }//if number not in range 
                    else {
                        System.out.println("Not in range number request " + min + " - " + max);
                    }
                } 
            }
        }


    /**
     * Get a double number from input
     *
     * @param message
     * @param error
     * @return a double number
     */
    public static double getDouble(String message, String error) {
        //0-9 matches a single character in the range between 0 and 9
        //matches the previous token between one and unlimited times, as many times as possible, giving back as needed
        // . is matches .
        String REGEX_NUMBER = "[0-9.]+";
        //Loop until user enter right format
        while (true) {
            System.out.println(message);
            String result = scanner.nextLine();
            //Check if result is empty
            if (result.isEmpty()) {
                System.out.println("Input cannot be empty");
            }//Check if result is not match REGEX_NUMBER 
            else if (result.matches(REGEX_NUMBER) == false) {
                System.out.println(error);
            } else {
                try {
                    double number = Double.parseDouble(result);
                    if (number > 0) {
                        return number;
                    } else {
                        System.out.println("Must be bigger than 0.");

                    }

                } catch (NumberFormatException e) {
                    System.out.println("Parse error.");

                }
            }
        }
    }

    /**
     * Return a string from user input
     *
     * @param message
     * @param error
     * @param REGEX
     * @return a string
     */
    public static String getString(String message, String error, String REGEX) {
        //Loop if user input wrong
        while (true) {
            System.out.println(message);
            String input = scanner.nextLine();
            //check if input is empty
            if (input.isEmpty()) {
                System.out.println("Empty !");
                //check if input not match regex    
            } else if (!input.matches(REGEX)) {
                System.out.println(error);
            } else {
                return input;
            }
        }
    }

    /**
     * Check date is in format and check age
     *
     * @param message
     * @param error
     * @param regex
     * @return date
     */
    public static String getDate(String message, String error, String regex) {
        //Loop until user enter right format
        while (true) {
            System.out.println(message);
            String input = scanner.nextLine();
            //Check if input is empty
            if (input.isEmpty()) {
                System.out.println("Input can't be empty.");
            }//Check if input is not match REGEX
            else {
                if (!input.matches(regex)) {
                    System.out.println(error);
                } else {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
                    //Check date is exist or not
                    dateFormat.setLenient(false);
                    try {
                        Date currentDate = new Date();
                        //format date type to dd/MM/yyyy
                        String currentDateString = dateFormat.format(currentDate);
                        //Check if date1 is less than date2
                        boolean checkDateLessThanCurrentDate = checkDate1_Less_Than_Date2(input, currentDateString);
                        /*
                        If variable about == true => return that value
                         */
                        if (checkDateLessThanCurrentDate == false) {
                            System.out.println("Date must be less than " + currentDateString);
                        } else {
                            Date date = dateFormat.parse(input);
                            //Converting obtained Date object to LocalDate object
                            /*
                            The toinstant() method is used to convert Date object 
                            to an Instant. The conversion creates an Instant that 
                            represents the same point on the time-line as this Date.
                            */
                            
                            Instant instant = date.toInstant();
                            //return the system default time-zone.
                            ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
                            LocalDate givenDate = zone.toLocalDate();
                            //Converting obtained Date object to LocalDate object
                            Period period = Period.between(givenDate, LocalDate.now());
                            if (period.getYears() < 18) {
                                System.out.println("This person is not enough 18 years old to work.");
                            } else {
                                return input;
                            }
                        }
                    } catch (Exception e) {
                        System.out.println("This date doesn't exist.");
                    }
                }
            }
        }
    }

    /**
     *
     * @param input
     * @param currenDateString
     * @return
     */
    private static boolean checkDate1_Less_Than_Date2(String input, String currenDateString) {
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        try {
            Date firstDate = dateFormat.parse(input);
            Date secondDate = dateFormat.parse(currenDateString);
            //Check if first date is before second date
            if (firstDate.before(secondDate)) {
                return true;
            }//Check if first date is after second date 
            else if (firstDate.after(secondDate)) {
                return false;
            } else {
                return false;
            }
        } catch (ParseException ex) {
            System.out.println("Parse error.");
        }
        return false;

    }
}
