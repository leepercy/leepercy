/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import controller.ManageEmployee;
import model.Employee;

/**
 *
 * @author leeph
 */
public class Main {

    static ViewEmployee view = new ViewEmployee();
    static ManageEmployee manage = new ManageEmployee();

    public static void main(String[] args) throws Exception {
        while (true) {
            //Display menu
            view.displayMenu();
            //Check choice if not empty, match REGEX_NUMBER or not
            int choice = Utility.getInt("Your choice: ", "Please input a digit.", 1, 6);
            switch (choice) {
                case 1:
                    view.addEmployees();
                    break;
                case 2:
                    view.updateEmployees();
                    break;
                case 3:
                    view.removeEmployees();
                    break;
                case 4:
                    view.searchEmployees();
                    break;
                case 5:
                    view.sortEmployeesBySalary();
                    break;
                case 6:
                    System.exit(0);
            }
        }
    }
}
