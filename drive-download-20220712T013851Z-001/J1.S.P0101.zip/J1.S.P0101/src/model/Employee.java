/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import view.Utility;

/**
 *
 * @author leeph
 */
public class Employee {

    private String id, firstName, lastName, phone, email, address, DOB, agency;
    private double salary;
    private int sex;

    public Employee() {
    }

    /**
     * Creates an employee information object
     */
    public Employee(String id,String firstName, String lastName, String phone, String email, String address, String DOB, String agency, double salary, int sex) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.DOB = DOB;
        this.agency = agency;
        this.salary = salary;
        this.sex = sex;
    }

    /**
     * Returns the number of id in employee's information
     *
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * This id has been auto_Increment
     *
     * @param id
     */
    public void setId(String id) {
        if (!id.isEmpty()) {
            this.id = id;
        }
    }

    /**
     * Return the first name of employee
     *
     * @return first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name of employee not empty
     *
     * @param firstName
     */
    public void setFirstName(String firstName) {
        if (!firstName.isEmpty()) {
            this.firstName = firstName;
        }
    }

    /**
     *
     * @return the last name of user
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the last name of employee not empty
     *
     * @param lastName
     */
    public void setLastName(String lastName) {
        if (!lastName.isEmpty()) {
            this.lastName = lastName;
        }
    }

    /**
     *
     * @return a phone number of employee
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Sets phone number not empty and match format
     *
     * @param phone
     * @throws java.lang.Exception
     */
    public void setPhone(String phone) throws Exception {
        if (!phone.isEmpty()) {
            if (phone.matches("[0][0-9]{9,10}")) {
                this.phone = phone;
            } else {
                throw new Exception("Wrong format");
            }
        } else {
            throw new Exception("Phone can not be empty.");
        }
    }

    /**
     * Return email value
     *
     * @return an email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets email not empty
     *
     * @param email
     * @throws java.lang.Exception
     */
    public void setEmail(String email) throws Exception {
        if (!email.isEmpty()) {
            
            if (email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
                this.email = email;
            } else {
                throw new Exception("Wrong format");
            }
        } else {
            throw new Exception("Email can not be empty.");
        }
        //format in email
        //cần thêm xác thực điện thoại
        //đối với những cái cần xác thực thì cần thêm try-catch ngoại lệ
    }

    /**
     *
     * @return an address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets address not empty
     *
     * @param address
     */
    public void setAddress(String address) {
        if (!address.isEmpty()) {
            this.address = address;
        }
    }

    /**
     *
     * @return date of birth
     */
    public String getDOB() {
        return DOB;
    }

    /**
     * Sets date of birth not empty
     *
     * @param DOB
     * @throws java.lang.Exception
     */
    public void setDOB(String DOB) throws Exception {
        if (!DOB.isEmpty()) {
            if (DOB.matches("dd/MM/yyyy")) {
                this.DOB = DOB;
            }else{
                throw new Exception("Wrong format.");
            }
        } else {
            throw new Exception("Date of birth can not be empty.");
        }
    }

    /**
     *
     * @return agency
     */
    public String getAgency() {
        return agency;
    }

    /**
     * Sets agency not empty
     *
     * @param agency
     */
    public void setAgency(String agency) {
        if (!agency.isEmpty()) {
            this.agency = agency;
        }
    }

    /**
     *
     * @return salary
     */
    public double getSalary() {
        return salary;
    }

    /**
     * Sets salary not empty
     *
     * @param salary
     */
    public void setSalary(double salary) {
        if (salary > 0) {
            this.salary = salary;
        }
    }

    /**
     * This method allow user not to enter full of sex character, just press 1
     * is male or 0 is female
     *
     * @return sexResult
     */
    public String getSex() {
        String sexRESULT = null;
        switch (sex) {
            case 1:
                sexRESULT = "male";
                break;
            case 0:
                sexRESULT = "female";
                break;
        }
        return sexRESULT;
    }

    /**
     * Sets sex choice is 1 or 0
     *
     * @param sex
     */
    public void setSex(int sex) {
        switch (sex) {
            case 1:
                this.sex = sex;
                break;
            case 0:
                this.sex = sex;
                break;
            default:
                return;
        }
    }

    /**
     * Print format output.
     *
     * @return
     */
    @Override
    public String toString() {
        return String.format("%-5s|%-20s|%-20s|%-20s|%-20s|%-20s|%-13s|%-10s|"
                + "%-10s|%-10s", id, firstName, lastName, phone, email, address, DOB, getSex(), salary, agency);
    }

}
