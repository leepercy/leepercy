/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import model.Employee;

/**
 *
 * @author leeph
 */
public class ManageEmployee {
    

    List<Employee> listEmployees = new ArrayList<>();
    

    /**
     * Access into list of Employee
     * @return listEmployee
     */
    public List<Employee> getListEmployee() {
        return listEmployees;
    }

    /**
     * Add new employee to listEmployee
     * @param employee 
     */
    public void addEmployee(Employee employee) {
        listEmployees.add(employee);
    }

    /**
     * Use for searching ID 
     * @param id
     * @return 
     */
    public Employee getEmployeeByID(String id) {
        for (Employee employee : listEmployees) {
            if (employee.getId().equals(id)) {
                return employee;
            }
        }
        return null;
    }

    /**
     * Check for duplicate id
     * @param IDUpdate
     * @return 
     */
    public boolean checkDuplicate(String IDUpdate) {
        for (Employee employee : listEmployees) {
            if (employee.getId().equals(IDUpdate)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Remove an employee from listEmployee
     * @param employee 
     */
    public void removeEmployee(Employee employee) {
        listEmployees.remove(employee);
    }

    /**
     * Searching employee by name or part of name
     * @param name
     * @return 
     */
    public List<Employee> getEmployeeByName(String name) {
        List<Employee> listSearch = new ArrayList<>();
        /**
         * Loop until find a name that contain a word that user enter
         */
        for (Employee employee : listEmployees) {
            String fullName = employee.getFirstName()+" "+ employee.getLastName();
            //If name contains a word that user want to find,
            //add user's information to listSearch.
            if (employee.getFirstName().toUpperCase().contains(name.toUpperCase())
                    || employee.getLastName().toUpperCase().contains(name.toUpperCase())
                    || fullName.toUpperCase().contains(name.toUpperCase())) {
                listSearch.add(employee);
            }
        }
        return listSearch;
    }

    /**
     * Sort employee's information by ascending salary
     * Using bubble sort.
     */
    public List<Employee> sortEmployee() {
        List<Employee> listSort = new ArrayList<>();
        listSort.addAll(listSort);
         /*Loop from the first to last person , 
        after each loop, one person is sorted*/
        for (int i = 0; i < listEmployees.size(); i++) {
            //Loop from first to last person through unsorted person
            for (int j = 0; j < listEmployees.size() - 1 - i; j++) {
                //swap two person if not in ascending order
                if (listEmployees.get(j).getSalary() > listEmployees.get(j + 1).getSalary()) {
                    Collections.swap(listEmployees, j, j + 1);
                }
            }
        }
        return listSort;
    }

}
